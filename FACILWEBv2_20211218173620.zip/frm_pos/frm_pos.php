<?php 
  include_once('../frm_pos/index.php'); 
?> 
