<?php 
  include_once('../blank_correo_reenvio2_contrato/index.php'); 
?> 
